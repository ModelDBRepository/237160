NeuroManager SSHLib Directory
Contains files from the SSH library by David Freedman and found at 
http://www.mathworks.com/matlabcentral/fileexchange/35409-ssh-sftp-scp-for-matlab--v2-

Some files have been modified for the convenience of NeuroManager installation
and operation.

Also contains the Ganymed SSH Java library jar file contained within the package
above.

dbs 11 December 2014
