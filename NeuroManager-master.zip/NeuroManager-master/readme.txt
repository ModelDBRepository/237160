Welcome to NeuroManager!

The final Frontiers in Neuroinformatics article and Supplemental Material can be seen at 

http://journal.frontiersin.org/article/10.3389/fninf.2015.00024/abstract

All installation and operation instructions are located in the "User and Programmer's Guide" in the UserGuide folder.


